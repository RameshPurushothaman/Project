package com.fasterxml.jackson.databind;

public @interface JsonNode {

}
