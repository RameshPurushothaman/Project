import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class json {

	public static void main(String[] args) throws FileNotFoundException {
		  try {   
	            File file1 = new File("task1:File1.txt");
	           
	            if (file1.createNewFile()) {  
	                       System.out.println("File " + file1.getName() + " is created successfully.");
	                       //System.out.println("File " + file2.getName() + " is created successfully.");
	                       
	            } else {  
	                       System.out.println("File is already exist in the directory.");  
	            }  
	          } catch (IOException exception) {  
	                   System.out.println("An unexpected error is occurred.");  
	                   exception.printStackTrace();  
	       }   

	        List<String> stngFile = new ArrayList<String>();

	        Scanner scnr = new Scanner(new FileReader(
	        		"task1:File1.txt"));    
	        
	        String str;
	        while (scnr.hasNext()) {
	                    str = scnr.next();
	                    stngFile.add(str);
	                }
	        String[] a=stngFile.toArray(new String[0]);
	      for(String b:a) {
	    	  
	    	  System.out.println(b);
	      }
	        
		
		
		
		
		
		
		

	}

}
