package file.ramesh;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;

public class Task_one_file_management {

	public static void main(String[] args) throws FileNotFoundException {
	
	//1----> query create two file and insert 20+ email minimum	
        try {   
            File file1 = new File("task1:File1.txt");
            File file2 = new File("task2:File2.txt");
           
            if (file1.createNewFile()&&file2.createNewFile()) {  
                       System.out.println("File " + file1.getName() + " is created successfully.");
                       System.out.println("File " + file2.getName() + " is created successfully.");
                       
            } else {  
                       System.out.println("File is already exist in the directory.");  
            }  
          } catch (IOException exception) {  
                   System.out.println("An unexpected error is occurred.");  
                   exception.printStackTrace();  
       }   
//insert 20+ email in the files
        try {  
            FileWriter write1 = new FileWriter("task1:File1.txt");  
            FileWriter write2 = new FileWriter("task2:File2.txt");  
            write1.write("Shiva@gmail.com\n"+ "Krishna@gmail.com\n"+ "Saanvi@gmail.com\n"+"Aditya@gmail.com\n"+ "Aarna@gmail.com\n"+ "Arya@gmail.com\n" + "Abhay@gmail.com\n"+ "Anika@gmail.com\n"	+ "Gautam@gmail.com\n"+ "kabir@gmail.com\n");   
            write2.write("Aditi@gmail.com\n"+ "Aarush@gmail.com\n"	+ "Dhruv@gmail.com\n"	+ "vikram@gmail.com\n"	+ "Shiva@gmail.com\n"+ "Krishna@gmail.com\n"	+ "Saanvi@gmail.com\n"+ "Aditya@gmail.com\n"+ "Aarna@gmail.com\n"+ "kabir@gmail.com");
            write1.close(); 
            write2.close();
            System.out.println("Content is successfully wrote to the file.");  
        
                
        
        } catch (IOException e) {  
            System.out.println("Unexpected error occurred");  
            
      
            e.printStackTrace();  
            }         
  //sorting the duplicate print only the unique value
        List<String> stngFile = new ArrayList<String>();

        Scanner scnr = new Scanner(new FileReader(
        		"task1:File1.txt"));    
        
        String str;
        while (scnr.hasNext()) {
                    str = scnr.next();
                    stngFile.add(str);
                }
        String[] a=stngFile.toArray(new String[0]);
      //System.out.println(a[1]);
        
      List<String> stngFile1 = new ArrayList<String>();

      Scanner scnr1 = new Scanner(new FileReader(
      		"task2:File2.txt"));    
      
      String str1;
      while (scnr1.hasNext()) {
                  str1 = scnr1.next();
                  stngFile1.add(str1);
              }
      String[] b=stngFile1.toArray(new String[0]);
   int a1=a.length;
   int b1=b.length;
   int pos=0;
   String []c=new String[a1+b1];
   for(String d:a) {
	   c[pos]=d;
	   pos++;
   }
   for(String d1:b) {
	   c[pos]=d1;
	   pos++;
   }
     for(String d3:c) {
    	// System.out.println(d3);
     }
         // Convert the array to a HashSet to automatically remove duplicates
             HashSet<String> uniqueStrings = new HashSet<>(Arrays.asList(c));

             // Convert the HashSet back to an array
             String[] resultArray = uniqueStrings.toArray(new String[0]);

             // Print the result
             System.out.println(Arrays.toString(resultArray));
             
             
             for()
             
             
             
             
         }
     

}
